
# Oasis Infobyte - Data Science Internship Tasks

I started as a data science intern at Oasis Infobyte for one month, and I had five tasks to perform. So, these are the tasks that I have completed.

## Tasks

 - [Task 1 - Iris Flower Classification](https://github.com/Wydoinn/OIBSIP/tree/main/Task%201%20-%20Iris%20Flower%20Classification)
 - [Task 2 - Unemployment Analysis With Python](https://github.com/Wydoinn/OIBSIP/tree/main/Task%202%20-%20Unemployment%20Analysis%20With%20Python)
 - [Task 3 - Car Prediction With Machine Learning](https://github.com/Wydoinn/OIBSIP/tree/main/Task%203%20-%20Car%20Price%20Prediction%20With%20Machine%20Leanrning)
 - [Task 4 - Email Spam Detection With Machine Learning](https://github.com/Wydoinn/OIBSIP/tree/main/Task%204%20-%20Email%20Spam%20Detection%20With%20Machine%20Learning)
 - [Task 5 - Sales Predicition Using Python](https://github.com/Wydoinn/OIBSIP/tree/main/Task%205%20-%20Sales%20Prediction%20Using%20Python)
