# Conclusion
- In this task, I have used the Advertising Dataset.
- Then, I did an analysis and visualization of the dataset.
- And then I trained the model using Linear Regression Algorithm and predicted the values.
- Made a dataframe of actual and predicted values.
- Finally, made a visualization of actual and predicted values.
