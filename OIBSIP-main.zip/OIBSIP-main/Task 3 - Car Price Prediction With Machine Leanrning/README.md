# Car Price Prediciton With Machine Learning
- In this task, I took Car Price dataset and performed Linear Regression and Lasso Regression Algorithms to make model.
- Many analyses of the dataset were performed.
- Many visualizations of the dataset were created.
- Finally, I plotted a graph for actual vs. predicted values.
